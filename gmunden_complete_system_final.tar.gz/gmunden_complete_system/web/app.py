#!/usr/bin/env python3
"""
Gmunden Transparenz-Datenbank - Vollständige Web-Anwendung
Vereint alle Features aus den verschiedenen Projektversionen
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
import os
import sys
import logging
from pathlib import Path
import re
from typing import Dict, List, Any, Optional, Tuple
import hashlib
import time

# Backend-Module importieren
sys.path.append(str(Path(__file__).parent.parent))
from backend.data_manager import DataManager
from backend.nlp_processor import NLPProcessor
from backend.quality_monitor import QualityMonitor
from backend.fact_checker import FactChecker

# Logging konfigurieren
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('web/app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class GmundenTransparencyApp:
    """Hauptklasse für die Gmunden Transparenz-Anwendung"""
    
    def __init__(self):
        self.data_manager = DataManager()
        self.nlp_processor = NLPProcessor()
        self.quality_monitor = QualityMonitor()
        self.fact_checker = FactChecker()
        
        # Session State initialisieren
        if 'search_history' not in st.session_state:
            st.session_state.search_history = []
        if 'current_data' not in st.session_state:
            st.session_state.current_data = None
        if 'quality_score' not in st.session_state:
            st.session_state.quality_score = 1.0
    
    def configure_page(self):
        """Streamlit-Seite konfigurieren"""
        st.set_page_config(
            page_title="Gmunden Transparenz-Datenbank",
            page_icon="🏛️",
            layout="wide",
            initial_sidebar_state="expanded",
            menu_items={
                'Get Help': 'https://github.com/gmunden/transparenz-db',
                'Report a bug': 'https://github.com/gmunden/transparenz-db/issues',
                'About': "Gmunden Transparenz-Datenbank v2.0 - Vollständiger Zugang zu allen Gemeindedaten"
            }
        )
        
        # Custom CSS für besseres Design
        st.markdown("""
        <style>
        .main-header {
            background: linear-gradient(90deg, #1f4e79 0%, #2e7d32 100%);
            color: white;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            text-align: center;
        }
        .search-box {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            border-left: 4px solid #2e7d32;
            margin: 1rem 0;
        }
        .quality-indicator {
            position: fixed;
            top: 10px;
            right: 10px;
            z-index: 999;
            background: white;
            padding: 0.5rem;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .example-questions {
            background: #e3f2fd;
            padding: 1rem;
            border-radius: 10px;
            margin: 1rem 0;
        }
        .data-source-info {
            background: #fff3e0;
            padding: 0.5rem;
            border-radius: 5px;
            font-size: 0.8rem;
            margin-top: 0.5rem;
        }
        </style>
        """, unsafe_allow_html=True)
    
    def render_header(self):
        """Header mit Titel und Navigation rendern"""
        st.markdown("""
        <div class="main-header">
            <h1>🏛️ Gemeinde Gmunden - Transparenz-Datenbank</h1>
            <p>Vollständiger Zugang zu allen Gemeindedaten mit intelligenter deutscher Sprachsuche</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Qualitäts-Indikator
        quality_color = "🟢" if st.session_state.quality_score > 0.8 else "🟡" if st.session_state.quality_score > 0.6 else "🔴"
        st.markdown(f"""
        <div class="quality-indicator">
            {quality_color} Datenqualität: {st.session_state.quality_score:.1%}
        </div>
        """, unsafe_allow_html=True)
    
    def render_sidebar(self):
        """Sidebar mit Navigation und Einstellungen"""
        with st.sidebar:
            st.header("🔍 Navigation")
            
            # Hauptfunktionen
            page = st.selectbox(
                "Bereich auswählen:",
                ["🏠 Startseite", "💰 Finanzen", "📋 Protokolle", "📄 Dokumente", 
                 "📊 Statistiken", "🔧 Verwaltung", "ℹ️ Hilfe"]
            )
            
            st.divider()
            
            # Schnellfilter
            st.subheader("⚡ Schnellfilter")
            
            # Jahr-Filter
            available_years = self.data_manager.get_available_years()
            selected_years = st.multiselect(
                "Jahre:",
                available_years,
                default=available_years[-3:] if len(available_years) >= 3 else available_years
            )
            
            # Kategorie-Filter
            categories = self.data_manager.get_categories()
            selected_categories = st.multiselect(
                "Kategorien:",
                categories,
                default=[]
            )
            
            # Betrag-Filter
            if "💰 Finanzen" in page:
                min_amount = st.number_input("Mindestbetrag (€):", min_value=0, value=0)
                max_amount = st.number_input("Höchstbetrag (€):", min_value=0, value=1000000)
            
            st.divider()
            
            # Suchhistorie
            st.subheader("📚 Letzte Suchen")
            if st.session_state.search_history:
                for i, search in enumerate(st.session_state.search_history[-5:]):
                    if st.button(f"🔄 {search[:30]}...", key=f"history_{i}"):
                        return self.process_search(search)
            else:
                st.info("Noch keine Suchen durchgeführt")
            
            st.divider()
            
            # System-Info
            st.subheader("📊 System-Status")
            total_docs = self.data_manager.get_total_documents()
            st.metric("Dokumente", f"{total_docs:,}")
            
            last_update = self.data_manager.get_last_update()
            st.metric("Letztes Update", last_update.strftime("%d.%m.%Y") if last_update else "Unbekannt")
            
            return page, {
                'years': selected_years,
                'categories': selected_categories,
                'min_amount': min_amount if "💰 Finanzen" in page else None,
                'max_amount': max_amount if "💰 Finanzen" in page else None
            }
    
    def render_search_interface(self):
        """Hauptsuchinterface rendern"""
        st.markdown('<div class="search-box">', unsafe_allow_html=True)
        
        col1, col2 = st.columns([4, 1])
        
        with col1:
            search_query = st.text_input(
                "🔍 Ihre Frage in normaler deutscher Sprache:",
                placeholder="z.B. 'Wie viel gab die Gemeinde 2023 für Straßenreparaturen aus?'",
                help="Stellen Sie Ihre Frage in normaler deutscher Sprache. Das System versteht komplexe Anfragen."
            )
        
        with col2:
            search_button = st.button("🔍 Suchen", type="primary", use_container_width=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Beispiel-Fragen
        st.markdown('<div class="example-questions">', unsafe_allow_html=True)
        st.subheader("💡 Beispiel-Fragen zum Ausprobieren:")
        
        example_questions = [
            "Wie viel gab die Gemeinde 2023 für Straßen aus?",
            "Zeige mir alle Gemeinderatsprotokolle von 2022",
            "Welche Ausgaben über 10.000 Euro gab es im letzten Jahr?",
            "Finde Dokumente über Wasserleitungsprojekte",
            "Wie entwickelten sich die Personalkosten zwischen 2020 und 2023?",
            "Zeige mir die größten Ausgaben der letzten 5 Jahre"
        ]
        
        cols = st.columns(2)
        for i, question in enumerate(example_questions):
            with cols[i % 2]:
                if st.button(f"💬 {question}", key=f"example_{i}"):
                    return self.process_search(question)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        if search_button and search_query:
            return self.process_search(search_query)
        
        return None
    
    def process_search(self, query: str) -> Dict[str, Any]:
        """Suchanfrage verarbeiten"""
        logger.info(f"Processing search query: {query}")
        
        # Query zur Historie hinzufügen
        if query not in st.session_state.search_history:
            st.session_state.search_history.append(query)
            if len(st.session_state.search_history) > 20:
                st.session_state.search_history.pop(0)
        
        # NLP-Verarbeitung
        with st.spinner("🤖 Analysiere Ihre Anfrage..."):
            nlp_result = self.nlp_processor.analyze_query(query)
        
        # Datensuche
        with st.spinner("🔍 Durchsuche Datenbank..."):
            search_results = self.data_manager.search(nlp_result)
        
        # Qualitätsprüfung
        with st.spinner("✅ Prüfe Datenqualität..."):
            quality_score = self.quality_monitor.check_results(search_results)
            st.session_state.quality_score = quality_score
        
        # Fact-Checking
        with st.spinner("🔍 Verifiziere Ergebnisse..."):
            verified_results = self.fact_checker.verify_results(search_results, query)
        
        return {
            'query': query,
            'nlp_result': nlp_result,
            'results': verified_results,
            'quality_score': quality_score,
            'timestamp': datetime.now()
        }
    
    def render_results(self, search_data: Dict[str, Any]):
        """Suchergebnisse anzeigen"""
        if not search_data or not search_data.get('results'):
            st.warning("Keine Ergebnisse gefunden. Versuchen Sie eine andere Formulierung.")
            return
        
        results = search_data['results']
        nlp_result = search_data['nlp_result']
        
        # Ergebnis-Header
        st.subheader(f"📊 Ergebnisse für: '{search_data['query']}'")
        
        # Zusammenfassung
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Gefundene Einträge", len(results.get('data', [])))
        with col2:
            total_amount = sum(item.get('betrag', 0) for item in results.get('data', []) if item.get('betrag'))
            st.metric("Gesamtsumme", f"{total_amount:,.2f} €" if total_amount > 0 else "N/A")
        with col3:
            years = set(item.get('jahr') for item in results.get('data', []) if item.get('jahr'))
            st.metric("Zeitraum", f"{min(years)}-{max(years)}" if years else "N/A")
        with col4:
            st.metric("Datenqualität", f"{search_data['quality_score']:.1%}")
        
        # Visualisierungen
        if results.get('data'):
            self.render_visualizations(results['data'], nlp_result)
        
        # Detailtabelle
        self.render_data_table(results.get('data', []))
        
        # Datenquellen-Info
        self.render_data_sources(results.get('sources', []))
    
    def render_visualizations(self, data: List[Dict], nlp_result: Dict):
        """Datenvisualisierungen erstellen"""
        if not data:
            return
        
        df = pd.DataFrame(data)
        
        # Tabs für verschiedene Visualisierungen
        tab1, tab2, tab3, tab4 = st.tabs(["📊 Übersicht", "📈 Zeitverlauf", "🥧 Verteilung", "📋 Details"])
        
        with tab1:
            # Balkendiagramm nach Kategorien
            if 'kategorie' in df.columns and 'betrag' in df.columns:
                fig = px.bar(
                    df.groupby('kategorie')['betrag'].sum().reset_index(),
                    x='kategorie', y='betrag',
                    title="Ausgaben nach Kategorien",
                    labels={'betrag': 'Betrag (€)', 'kategorie': 'Kategorie'}
                )
                fig.update_layout(xaxis_tickangle=-45)
                st.plotly_chart(fig, use_container_width=True)
        
        with tab2:
            # Zeitverlauf
            if 'jahr' in df.columns and 'betrag' in df.columns:
                yearly_data = df.groupby('jahr')['betrag'].sum().reset_index()
                fig = px.line(
                    yearly_data,
                    x='jahr', y='betrag',
                    title="Ausgaben-Entwicklung über Zeit",
                    labels={'betrag': 'Betrag (€)', 'jahr': 'Jahr'},
                    markers=True
                )
                st.plotly_chart(fig, use_container_width=True)
        
        with tab3:
            # Kreisdiagramm Top-Kategorien
            if 'kategorie' in df.columns and 'betrag' in df.columns:
                top_categories = df.groupby('kategorie')['betrag'].sum().nlargest(10)
                fig = px.pie(
                    values=top_categories.values,
                    names=top_categories.index,
                    title="Top 10 Ausgaben-Kategorien"
                )
                st.plotly_chart(fig, use_container_width=True)
        
        with tab4:
            # Detaillierte Statistiken
            st.subheader("📊 Statistische Auswertung")
            
            if 'betrag' in df.columns:
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Durchschnitt", f"{df['betrag'].mean():,.2f} €")
                    st.metric("Median", f"{df['betrag'].median():,.2f} €")
                    st.metric("Minimum", f"{df['betrag'].min():,.2f} €")
                with col2:
                    st.metric("Maximum", f"{df['betrag'].max():,.2f} €")
                    st.metric("Standardabweichung", f"{df['betrag'].std():,.2f} €")
                    st.metric("Gesamtsumme", f"{df['betrag'].sum():,.2f} €")
    
    def render_data_table(self, data: List[Dict]):
        """Detaillierte Datentabelle anzeigen"""
        if not data:
            return
        
        st.subheader("📋 Detaillierte Ergebnisse")
        
        df = pd.DataFrame(data)
        
        # Spalten für bessere Darstellung formatieren
        if 'betrag' in df.columns:
            df['betrag'] = df['betrag'].apply(lambda x: f"{x:,.2f} €" if pd.notnull(x) else "N/A")
        
        if 'datum' in df.columns:
            df['datum'] = pd.to_datetime(df['datum'], errors='coerce').dt.strftime('%d.%m.%Y')
        
        # Interaktive Tabelle
        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "betrag": st.column_config.TextColumn("Betrag"),
                "datum": st.column_config.TextColumn("Datum"),
                "beschreibung": st.column_config.TextColumn("Beschreibung", width="large"),
                "kategorie": st.column_config.TextColumn("Kategorie"),
                "jahr": st.column_config.NumberColumn("Jahr")
            }
        )
        
        # Download-Button
        csv = df.to_csv(index=False)
        st.download_button(
            label="📥 Ergebnisse als CSV herunterladen",
            data=csv,
            file_name=f"gmunden_daten_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
    
    def render_data_sources(self, sources: List[str]):
        """Datenquellen-Information anzeigen"""
        if not sources:
            return
        
        st.markdown('<div class="data-source-info">', unsafe_allow_html=True)
        st.caption("📚 Datenquellen: " + ", ".join(sources))
        st.markdown('</div>', unsafe_allow_html=True)
    
    def render_finance_page(self, filters: Dict):
        """Finanz-Seite rendern"""
        st.header("💰 Finanzdaten")
        
        # Finanz-Dashboard
        finance_data = self.data_manager.get_finance_overview(filters)
        
        if finance_data:
            # KPIs
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Gesamtausgaben", f"{finance_data.get('total_expenses', 0):,.2f} €")
            with col2:
                st.metric("Gesamteinnahmen", f"{finance_data.get('total_income', 0):,.2f} €")
            with col3:
                budget_diff = finance_data.get('total_income', 0) - finance_data.get('total_expenses', 0)
                st.metric("Saldo", f"{budget_diff:,.2f} €", delta=budget_diff)
            with col4:
                st.metric("Anzahl Transaktionen", f"{finance_data.get('transaction_count', 0):,}")
            
            # Detaillierte Finanzvisualisierungen
            self.render_finance_charts(finance_data)
    
    def render_finance_charts(self, data: Dict):
        """Finanz-spezifische Charts"""
        # Implementierung der Finanz-Charts
        pass
    
    def render_documents_page(self, filters: Dict):
        """Dokumente-Seite rendern"""
        st.header("📄 Dokumente")
        
        # Dokument-Upload
        uploaded_file = st.file_uploader(
            "📤 Neues Dokument hochladen",
            type=['pdf', 'docx', 'txt', 'xlsx', 'csv'],
            help="Unterstützte Formate: PDF, Word, Text, Excel, CSV"
        )
        
        if uploaded_file:
            with st.spinner("📄 Verarbeite Dokument..."):
                result = self.data_manager.process_uploaded_document(uploaded_file)
                if result['success']:
                    st.success(f"✅ Dokument erfolgreich verarbeitet: {result['filename']}")
                else:
                    st.error(f"❌ Fehler beim Verarbeiten: {result['error']}")
        
        # Dokument-Browser
        documents = self.data_manager.get_documents(filters)
        if documents:
            for doc in documents:
                with st.expander(f"📄 {doc['filename']} ({doc['type']})"):
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.write(f"**Beschreibung:** {doc.get('description', 'N/A')}")
                        st.write(f"**Datum:** {doc.get('date', 'N/A')}")
                        st.write(f"**Größe:** {doc.get('size', 'N/A')}")
                    with col2:
                        if st.button(f"📥 Download", key=f"download_{doc['id']}"):
                            # Download-Funktionalität
                            pass
    
    def render_statistics_page(self, filters: Dict):
        """Statistik-Seite rendern"""
        st.header("📊 Statistiken & Analysen")
        
        # Verschiedene Statistik-Widgets
        tab1, tab2, tab3 = st.tabs(["📈 Trends", "🔍 Analysen", "📊 Berichte"])
        
        with tab1:
            st.subheader("Trend-Analysen")
            # Trend-Visualisierungen
            
        with tab2:
            st.subheader("Detaillierte Analysen")
            # Detaillierte Analysen
            
        with tab3:
            st.subheader("Automatische Berichte")
            # Berichts-Generator
    
    def render_admin_page(self):
        """Verwaltungs-Seite rendern"""
        st.header("🔧 System-Verwaltung")
        
        # Admin-Funktionen nur für autorisierte Benutzer
        if st.checkbox("🔐 Admin-Modus aktivieren"):
            password = st.text_input("Passwort:", type="password")
            if password == "admin123":  # In Produktion durch sichere Authentifizierung ersetzen
                
                tab1, tab2, tab3, tab4 = st.tabs(["📊 System", "📥 Import", "🔧 Wartung", "📋 Logs"])
                
                with tab1:
                    st.subheader("System-Status")
                    # System-Monitoring
                    
                with tab2:
                    st.subheader("Daten-Import")
                    # Import-Tools
                    
                with tab3:
                    st.subheader("Wartung")
                    # Wartungs-Tools
                    
                with tab4:
                    st.subheader("System-Logs")
                    # Log-Viewer
    
    def render_help_page(self):
        """Hilfe-Seite rendern"""
        st.header("ℹ️ Hilfe & Dokumentation")
        
        tab1, tab2, tab3 = st.tabs(["🚀 Erste Schritte", "❓ FAQ", "📞 Kontakt"])
        
        with tab1:
            st.markdown("""
            ## 🚀 Erste Schritte
            
            ### 1. Suche verwenden
            - Stellen Sie Fragen in normaler deutscher Sprache
            - Beispiel: "Wie viel gab die Gemeinde 2023 für Straßen aus?"
            
            ### 2. Filter nutzen
            - Verwenden Sie die Sidebar-Filter für präzisere Ergebnisse
            - Kombinieren Sie Jahr-, Kategorie- und Betragsfilter
            
            ### 3. Ergebnisse analysieren
            - Nutzen Sie die verschiedenen Visualisierungs-Tabs
            - Laden Sie Daten als CSV herunter
            """)
        
        with tab2:
            st.markdown("""
            ## ❓ Häufig gestellte Fragen
            
            **Q: Wie aktuell sind die Daten?**
            A: Die Daten werden regelmäßig aktualisiert. Das letzte Update sehen Sie in der Sidebar.
            
            **Q: Kann ich eigene Dokumente hochladen?**
            A: Ja, im Dokumente-Bereich können Sie PDFs, Word-Dokumente und andere Formate hochladen.
            
            **Q: Wie funktioniert die Sprachsuche?**
            A: Das System verwendet KI, um deutsche Anfragen zu verstehen und passende Daten zu finden.
            """)
        
        with tab3:
            st.markdown("""
            ## 📞 Kontakt & Support
            
            **Gemeinde Gmunden**
            - 📧 E-Mail: transparenz@gmunden.at
            - 📞 Telefon: +43 7612 794-0
            - 🌐 Website: www.gmunden.at
            
            **Technischer Support**
            - 📧 E-Mail: it-support@gmunden.at
            - 🐛 Bug-Reports: GitHub Issues
            """)
    
    def run(self):
        """Hauptanwendung ausführen"""
        try:
            # Seite konfigurieren
            self.configure_page()
            
            # Header rendern
            self.render_header()
            
            # Sidebar und Navigation
            page, filters = self.render_sidebar()
            
            # Hauptinhalt basierend auf ausgewählter Seite
            if page == "🏠 Startseite":
                search_result = self.render_search_interface()
                if search_result:
                    self.render_results(search_result)
                    st.session_state.current_data = search_result
            
            elif page == "💰 Finanzen":
                self.render_finance_page(filters)
            
            elif page == "📋 Protokolle":
                st.header("📋 Protokolle")
                st.info("Protokoll-Funktionalität wird implementiert...")
            
            elif page == "📄 Dokumente":
                self.render_documents_page(filters)
            
            elif page == "📊 Statistiken":
                self.render_statistics_page(filters)
            
            elif page == "🔧 Verwaltung":
                self.render_admin_page()
            
            elif page == "ℹ️ Hilfe":
                self.render_help_page()
            
            # Footer
            st.divider()
            st.markdown("""
            <div style='text-align: center; color: #666; padding: 1rem;'>
                🏛️ Gemeinde Gmunden Transparenz-Datenbank v2.0 | 
                Entwickelt für vollständige Bürgertransparenz | 
                Alle Daten werden in Echtzeit validiert
            </div>
            """, unsafe_allow_html=True)
            
        except Exception as e:
            logger.error(f"Application error: {str(e)}")
            st.error(f"Ein Fehler ist aufgetreten: {str(e)}")
            st.info("Bitte versuchen Sie es erneut oder kontaktieren Sie den Support.")

def main():
    """Hauptfunktion"""
    app = GmundenTransparencyApp()
    app.run()

if __name__ == "__main__":
    main()