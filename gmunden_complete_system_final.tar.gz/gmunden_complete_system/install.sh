#!/usr/bin/env bash
# Gmunden Transparenz-Datenbank - Vollständiges Install-Script
# Erstellt Docker-VM, installiert alles und startet die Oberfläche

set -euo pipefail

# Farben für Output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Konfiguration
PROJECT_NAME="gmunden-transparenz-db"
DOCKER_COMPOSE_VERSION="2.21.0"
MONGODB_VERSION="7.0"
PYTHON_VERSION="3.11"
WEB_PORT="12000"
MONGO_PORT="27017"
OCR_PORT="8080"

# Logging
LOG_FILE="install.log"
exec 1> >(tee -a "$LOG_FILE")
exec 2> >(tee -a "$LOG_FILE" >&2)

# Funktionen
print_header() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                    🏛️  GMUNDEN TRANSPARENZ-DATENBANK                        ║"
    echo "║                         Vollständiges Install-Script                        ║"
    echo "║                              Version 2.0.0                                  ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_step() {
    echo -e "${CYAN}[$(date '+%H:%M:%S')] 🔧 $1${NC}"
}

print_success() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')] ✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')] ⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')] ❌ $1${NC}"
}

print_info() {
    echo -e "${PURPLE}[$(date '+%H:%M:%S')] ℹ️  $1${NC}"
}

check_system() {
    print_step "Überprüfe System-Voraussetzungen..."
    
    # Betriebssystem prüfen
    if [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macOS"
        print_info "Erkanntes System: macOS"
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        OS="Linux"
        print_info "Erkanntes System: Linux"
    else
        print_error "Nicht unterstütztes Betriebssystem: $OSTYPE"
        exit 1
    fi
    
    # Architektur prüfen
    ARCH=$(uname -m)
    print_info "Architektur: $ARCH"
    
    # Speicher prüfen
    if [[ "$OS" == "macOS" ]]; then
        MEMORY_GB=$(( $(sysctl -n hw.memsize) / 1024 / 1024 / 1024 ))
    else
        MEMORY_GB=$(( $(grep MemTotal /proc/meminfo | awk '{print $2}') / 1024 / 1024 ))
    fi
    
    print_info "Verfügbarer Speicher: ${MEMORY_GB}GB"
    
    if [ "$MEMORY_GB" -lt 4 ]; then
        print_warning "Weniger als 4GB RAM verfügbar. Performance könnte beeinträchtigt sein."
    fi
    
    # Festplattenspeicher prüfen
    DISK_FREE_GB=$(df -h . | awk 'NR==2 {print $4}' | sed 's/G.*//')
    print_info "Freier Festplattenspeicher: ${DISK_FREE_GB}GB"
    
    if [ "${DISK_FREE_GB%.*}" -lt 10 ]; then
        print_error "Weniger als 10GB freier Speicher verfügbar!"
        exit 1
    fi
    
    print_success "System-Voraussetzungen erfüllt"
}

install_docker() {
    print_step "Installiere Docker..."
    
    if command -v docker &> /dev/null; then
        print_info "Docker bereits installiert: $(docker --version)"
        
        # Docker läuft?
        if ! docker info &> /dev/null; then
            print_step "Starte Docker..."
            if [[ "$OS" == "macOS" ]]; then
                open -a Docker
                print_info "Warte auf Docker-Start..."
                sleep 10
                
                # Warten bis Docker läuft
                for i in {1..30}; do
                    if docker info &> /dev/null; then
                        break
                    fi
                    sleep 2
                done
                
                if ! docker info &> /dev/null; then
                    print_error "Docker konnte nicht gestartet werden!"
                    exit 1
                fi
            else
                sudo systemctl start docker
                sudo systemctl enable docker
            fi
        fi
    else
        print_step "Docker wird installiert..."
        
        if [[ "$OS" == "macOS" ]]; then
            # Homebrew prüfen/installieren
            if ! command -v brew &> /dev/null; then
                print_step "Installiere Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            
            # Docker Desktop installieren
            brew install --cask docker
            open -a Docker
            
            print_info "Warte auf Docker-Start..."
            sleep 15
            
            # Warten bis Docker läuft
            for i in {1..60}; do
                if docker info &> /dev/null; then
                    break
                fi
                sleep 2
            done
            
        else
            # Linux Docker Installation
            curl -fsSL https://get.docker.com -o get-docker.sh
            sudo sh get-docker.sh
            sudo usermod -aG docker $USER
            sudo systemctl start docker
            sudo systemctl enable docker
            
            print_warning "Bitte melden Sie sich ab und wieder an, um Docker ohne sudo zu verwenden."
        fi
    fi
    
    # Docker Compose prüfen
    if ! docker compose version &> /dev/null; then
        if ! command -v docker-compose &> /dev/null; then
            print_error "Docker Compose nicht gefunden!"
            exit 1
        else
            print_info "Verwende docker-compose (v1)"
            COMPOSE_CMD="docker-compose"
        fi
    else
        print_info "Verwende docker compose (v2)"
        COMPOSE_CMD="docker compose"
    fi
    
    print_success "Docker erfolgreich installiert und gestartet"
}

install_python_deps() {
    print_step "Installiere Python-Abhängigkeiten..."
    
    # Python Version prüfen
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION_INSTALLED=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
        print_info "Python Version: $PYTHON_VERSION_INSTALLED"
        
        if [[ "$PYTHON_VERSION_INSTALLED" < "3.8" ]]; then
            print_error "Python 3.8+ erforderlich, gefunden: $PYTHON_VERSION_INSTALLED"
            exit 1
        fi
    else
        print_error "Python3 nicht gefunden!"
        exit 1
    fi
    
    # Virtual Environment erstellen
    if [ ! -d "venv" ]; then
        print_step "Erstelle Python Virtual Environment..."
        python3 -m venv venv
    fi
    
    # Virtual Environment aktivieren
    source venv/bin/activate
    
    # Pip upgraden
    pip install --upgrade pip
    
    # Requirements installieren
    if [ -f "config/requirements.txt" ]; then
        print_step "Installiere Python-Pakete..."
        pip install -r config/requirements.txt
        
        # Optionale Pakete (mit Fehlerbehandlung)
        print_step "Installiere optionale Pakete..."
        
        # spaCy deutsches Modell
        if pip show spacy &> /dev/null; then
            python -m spacy download de_core_news_sm || print_warning "Deutsches spaCy-Modell konnte nicht installiert werden"
        fi
        
        # Tesseract für OCR
        if [[ "$OS" == "macOS" ]]; then
            if command -v brew &> /dev/null; then
                brew install tesseract tesseract-lang || print_warning "Tesseract konnte nicht installiert werden"
            fi
        else
            if command -v apt-get &> /dev/null; then
                sudo apt-get update
                sudo apt-get install -y tesseract-ocr tesseract-ocr-deu || print_warning "Tesseract konnte nicht installiert werden"
            fi
        fi
        
    else
        print_error "requirements.txt nicht gefunden!"
        exit 1
    fi
    
    print_success "Python-Abhängigkeiten installiert"
}

create_docker_files() {
    print_step "Erstelle Docker-Konfiguration..."
    
    # Dockerfile erstellen
    cat > Dockerfile << 'EOF'
FROM python:3.11-slim

# System-Abhängigkeiten
RUN apt-get update && apt-get install -y \
    tesseract-ocr \
    tesseract-ocr-deu \
    poppler-utils \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Arbeitsverzeichnis
WORKDIR /app

# Python-Abhängigkeiten
COPY config/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# spaCy deutsches Modell (optional)
RUN python -m spacy download de_core_news_sm || echo "spaCy model download failed"

# Anwendung kopieren
COPY . .

# Verzeichnisse erstellen
RUN mkdir -p data/imports data/processed data/backups logs

# Port freigeben
EXPOSE 12000

# Gesundheitscheck
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \
    CMD curl -f http://localhost:12000/_stcore/health || exit 1

# Startbefehl
CMD ["streamlit", "run", "web/app.py", "--server.port=12000", "--server.address=0.0.0.0", "--server.enableCORS=true"]
EOF

    # docker-compose.yml erstellen
    cat > docker-compose.yml << EOF
version: '3.8'

services:
  web:
    build: .
    container_name: ${PROJECT_NAME}-web
    ports:
      - "${WEB_PORT}:12000"
    environment:
      - PYTHONPATH=/app
      - STREAMLIT_SERVER_PORT=12000
      - STREAMLIT_SERVER_ADDRESS=0.0.0.0
      - MONGODB_HOST=mongodb
      - MONGODB_PORT=27017
    volumes:
      - ./data:/app/data
      - ./config:/app/config
      - ./logs:/app/logs
    depends_on:
      - mongodb
    restart: unless-stopped
    networks:
      - gmunden-network

  mongodb:
    image: mongo:${MONGODB_VERSION}
    container_name: ${PROJECT_NAME}-mongodb
    ports:
      - "${MONGO_PORT}:27017"
    environment:
      - MONGO_INITDB_ROOT_USERNAME=admin
      - MONGO_INITDB_ROOT_PASSWORD=change_me_strong
      - MONGO_INITDB_DATABASE=gmunden_db
    volumes:
      - mongodb_data:/data/db
      - ./database/init.js:/docker-entrypoint-initdb.d/init.js:ro
    restart: unless-stopped
    networks:
      - gmunden-network
    healthcheck:
      test: ["CMD", "mongosh", "--eval", "db.adminCommand('ping')"]
      interval: 30s
      timeout: 10s
      retries: 5

  ocr-agent:
    build: ./ocr-agent
    container_name: ${PROJECT_NAME}-ocr
    ports:
      - "${OCR_PORT}:8080"
    environment:
      - OCR_LANGUAGE=deu
      - OCR_DPI=300
    volumes:
      - ./data/uploads:/app/uploads
      - ./data/processed:/app/processed
    restart: unless-stopped
    networks:
      - gmunden-network

volumes:
  mongodb_data:
    driver: local

networks:
  gmunden-network:
    driver: bridge
EOF

    # MongoDB Init-Script
    mkdir -p database
    cat > database/init.js << 'EOF'
// MongoDB Initialisierung für Gmunden Transparenz-DB

db = db.getSiblingDB('gmunden_db');

// Collections erstellen
db.createCollection('finanzen');
db.createCollection('dokumente');
db.createCollection('protokolle');
db.createCollection('jahre');

// Indizes erstellen
db.finanzen.createIndex({ jahr: 1 });
db.finanzen.createIndex({ kategorie: 1 });
db.finanzen.createIndex({ betrag: -1 });
db.finanzen.createIndex({ datum: -1 });

db.dokumente.createIndex({ jahr: 1 });
db.dokumente.createIndex({ typ: 1 });
db.dokumente.createIndex({ filename: "text", titel: "text", inhalt: "text" });

db.protokolle.createIndex({ datum: -1 });
db.protokolle.createIndex({ typ: 1 });

db.jahre.createIndex({ jahr: 1 });

// Status-Eintrag
db.status.insertOne({
    _id: "init",
    initialized: new Date(),
    version: "2.0.0",
    status: "ready"
});

print("Gmunden Transparenz-DB initialized successfully");
EOF

    # OCR-Agent Dockerfile
    mkdir -p ocr-agent
    cat > ocr-agent/Dockerfile << 'EOF'
FROM python:3.11-slim

RUN apt-get update && apt-get install -y \
    tesseract-ocr \
    tesseract-ocr-deu \
    poppler-utils \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app.py .

EXPOSE 8080

CMD ["python", "app.py"]
EOF

    # OCR-Agent Requirements
    cat > ocr-agent/requirements.txt << 'EOF'
flask==2.3.3
pytesseract==0.3.10
Pillow==10.0.0
PyMuPDF==1.23.0
requests==2.31.0
EOF

    # OCR-Agent App
    cat > ocr-agent/app.py << 'EOF'
#!/usr/bin/env python3
"""
OCR-Agent für Gmunden Transparenz-Datenbank
Einfacher Flask-Service für Dokumentenverarbeitung
"""

from flask import Flask, request, jsonify
import pytesseract
from PIL import Image
import fitz  # PyMuPDF
import io
import os
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'service': 'ocr-agent'})

@app.route('/ocr', methods=['POST'])
def process_ocr():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Datei lesen
        file_content = file.read()
        filename = file.filename.lower()
        
        extracted_text = ""
        
        if filename.endswith('.pdf'):
            # PDF verarbeiten
            pdf_doc = fitz.open(stream=file_content, filetype="pdf")
            for page_num in range(pdf_doc.page_count):
                page = pdf_doc[page_num]
                text = page.get_text()
                if text.strip():
                    extracted_text += text + "\n"
                else:
                    # OCR für gescannte Seiten
                    pix = page.get_pixmap()
                    img_data = pix.tobytes("png")
                    image = Image.open(io.BytesIO(img_data))
                    ocr_text = pytesseract.image_to_string(image, lang='deu')
                    extracted_text += ocr_text + "\n"
            pdf_doc.close()
            
        elif filename.endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp')):
            # Bild verarbeiten
            image = Image.open(io.BytesIO(file_content))
            extracted_text = pytesseract.image_to_string(image, lang='deu')
        
        else:
            return jsonify({'error': 'Unsupported file type'}), 400
        
        return jsonify({
            'success': True,
            'filename': file.filename,
            'extracted_text': extracted_text.strip(),
            'text_length': len(extracted_text.strip())
        })
        
    except Exception as e:
        app.logger.error(f"OCR processing error: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)
EOF

    print_success "Docker-Konfiguration erstellt"
}

setup_directories() {
    print_step "Erstelle Verzeichnisstruktur..."
    
    # Verzeichnisse erstellen
    mkdir -p data/{imports,processed,backups,uploads}
    mkdir -p logs
    mkdir -p config
    
    # .gitignore erstellen
    cat > .gitignore << 'EOF'
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
env/
ENV/

# Logs
*.log
logs/

# Data
data/
!data/.gitkeep

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Docker
.dockerignore

# Secrets
.env
*.key
*.pem
EOF

    # .gitkeep Dateien
    touch data/imports/.gitkeep
    touch data/processed/.gitkeep
    touch data/backups/.gitkeep
    touch data/uploads/.gitkeep
    touch logs/.gitkeep
    
    print_success "Verzeichnisstruktur erstellt"
}

build_and_start() {
    print_step "Baue und starte Docker-Container..."
    
    # Docker Images bauen
    print_info "Baue Docker Images..."
    $COMPOSE_CMD build --no-cache
    
    # Container starten
    print_info "Starte Container..."
    $COMPOSE_CMD up -d
    
    # Warten auf Services
    print_info "Warte auf Service-Start..."
    sleep 10
    
    # Health Checks
    print_step "Prüfe Service-Status..."
    
    # MongoDB
    for i in {1..30}; do
        if docker exec ${PROJECT_NAME}-mongodb mongosh --eval "db.adminCommand('ping')" &> /dev/null; then
            print_success "MongoDB ist bereit"
            break
        fi
        sleep 2
    done
    
    # Web-Service
    for i in {1..60}; do
        if curl -f http://localhost:${WEB_PORT}/_stcore/health &> /dev/null; then
            print_success "Web-Service ist bereit"
            break
        fi
        sleep 2
    done
    
    # OCR-Agent
    for i in {1..30}; do
        if curl -f http://localhost:${OCR_PORT}/health &> /dev/null; then
            print_success "OCR-Agent ist bereit"
            break
        fi
        sleep 2
    done
    
    print_success "Alle Services gestartet"
}

create_management_scripts() {
    print_step "Erstelle Management-Scripts..."
    
    # Start-Script
    cat > start.sh << EOF
#!/bin/bash
echo "🚀 Starte Gmunden Transparenz-Datenbank..."
$COMPOSE_CMD up -d
echo "✅ Services gestartet"
echo "🌐 Web-Interface: http://localhost:${WEB_PORT}"
echo "🗄️  MongoDB: localhost:${MONGO_PORT}"
echo "🔍 OCR-Agent: http://localhost:${OCR_PORT}"
EOF
    chmod +x start.sh
    
    # Stop-Script
    cat > stop.sh << EOF
#!/bin/bash
echo "🛑 Stoppe Gmunden Transparenz-Datenbank..."
$COMPOSE_CMD down
echo "✅ Services gestoppt"
EOF
    chmod +x stop.sh
    
    # Status-Script
    cat > status.sh << EOF
#!/bin/bash
echo "📊 Status der Gmunden Transparenz-Datenbank:"
echo "============================================="
$COMPOSE_CMD ps
echo ""
echo "🌐 Web-Interface: http://localhost:${WEB_PORT}"
echo "🗄️  MongoDB: localhost:${MONGO_PORT}"
echo "🔍 OCR-Agent: http://localhost:${OCR_PORT}"
EOF
    chmod +x status.sh
    
    # Backup-Script
    cat > backup.sh << EOF
#!/bin/bash
BACKUP_DIR="data/backups"
TIMESTAMP=\$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="\${BACKUP_DIR}/gmunden_backup_\${TIMESTAMP}.tar.gz"

echo "💾 Erstelle Backup..."
mkdir -p \$BACKUP_DIR

# MongoDB Backup
docker exec ${PROJECT_NAME}-mongodb mongodump --archive --gzip > "\${BACKUP_DIR}/mongodb_\${TIMESTAMP}.archive.gz"

# Dateien Backup
tar -czf "\$BACKUP_FILE" data/ config/ --exclude=data/backups

echo "✅ Backup erstellt: \$BACKUP_FILE"
EOF
    chmod +x backup.sh
    
    # Update-Script
    cat > update.sh << EOF
#!/bin/bash
echo "🔄 Update Gmunden Transparenz-Datenbank..."
git pull
$COMPOSE_CMD build --no-cache
$COMPOSE_CMD up -d
echo "✅ Update abgeschlossen"
EOF
    chmod +x update.sh
    
    print_success "Management-Scripts erstellt"
}

show_final_info() {
    print_success "Installation erfolgreich abgeschlossen!"
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                    🎉 INSTALLATION ERFOLGREICH! 🎉                          ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    echo -e "${CYAN}📍 ZUGRIFF AUF DIE ANWENDUNG:${NC}"
    echo -e "   🌐 Web-Interface:     ${BLUE}http://localhost:${WEB_PORT}${NC}"
    echo -e "   🌍 Extern (All-Hands): ${BLUE}https://work-1-syygiirqlvvwfggb.prod-runtime.all-hands.dev${NC}"
    echo ""
    
    echo -e "${CYAN}🔧 SYSTEM-KOMPONENTEN:${NC}"
    echo -e "   🗄️  MongoDB:          ${BLUE}localhost:${MONGO_PORT}${NC}"
    echo -e "   🔍 OCR-Agent:         ${BLUE}http://localhost:${OCR_PORT}${NC}"
    echo -e "   📊 Container Status:   ${BLUE}./status.sh${NC}"
    echo ""
    
    echo -e "${CYAN}🚀 ERSTE SCHRITTE:${NC}"
    echo -e "   1. Öffnen Sie ${BLUE}http://localhost:${WEB_PORT}${NC} in Ihrem Browser"
    echo -e "   2. Testen Sie die Suche: ${YELLOW}'Wie viel gab die Gemeinde 2023 für Straßen aus?'${NC}"
    echo -e "   3. Laden Sie Dokumente im ${BLUE}📄 Dokumente${NC}-Bereich hoch"
    echo -e "   4. Erkunden Sie die verschiedenen Funktionen"
    echo ""
    
    echo -e "${CYAN}🛠️  VERWALTUNG:${NC}"
    echo -e "   ▶️  Starten:           ${GREEN}./start.sh${NC}"
    echo -e "   ⏹️  Stoppen:           ${RED}./stop.sh${NC}"
    echo -e "   📊 Status:            ${BLUE}./status.sh${NC}"
    echo -e "   💾 Backup:            ${PURPLE}./backup.sh${NC}"
    echo -e "   🔄 Update:            ${YELLOW}./update.sh${NC}"
    echo ""
    
    echo -e "${CYAN}📋 SYSTEM-INFORMATIONEN:${NC}"
    echo -e "   🖥️  Betriebssystem:    ${OS}"
    echo -e "   💾 Speicher:          ${MEMORY_GB}GB"
    echo -e "   💿 Freier Speicher:   ${DISK_FREE_GB}GB"
    echo -e "   🐳 Docker:            $(docker --version | cut -d' ' -f3 | tr -d ',')"
    echo -e "   🐍 Python:            $(python3 --version | cut -d' ' -f2)"
    echo ""
    
    echo -e "${CYAN}🔐 STANDARD-ZUGANGSDATEN:${NC}"
    echo -e "   📊 Admin-Panel:       ${YELLOW}Passwort: admin123${NC} ${RED}(ÄNDERN!)${NC}"
    echo -e "   🗄️  MongoDB:          ${YELLOW}admin / change_me_strong${NC} ${RED}(ÄNDERN!)${NC}"
    echo ""
    
    echo -e "${CYAN}📚 BEISPIEL-ANFRAGEN:${NC}"
    echo -e "   • ${YELLOW}'Zeige mir alle Ausgaben von 2023'${NC}"
    echo -e "   • ${YELLOW}'Wie viel kostete die Straßenreparatur?'${NC}"
    echo -e "   • ${YELLOW}'Finde Protokolle über Wasserleitungen'${NC}"
    echo -e "   • ${YELLOW}'Welche Ausgaben über 10.000 Euro gab es?'${NC}"
    echo ""
    
    echo -e "${CYAN}🆘 SUPPORT:${NC}"
    echo -e "   📧 E-Mail:            ${BLUE}transparenz@gmunden.at${NC}"
    echo -e "   📋 Logs:              ${BLUE}tail -f logs/gmunden_app.log${NC}"
    echo -e "   🐛 Issues:            ${BLUE}GitHub Issues${NC}"
    echo ""
    
    echo -e "${GREEN}🎯 Das System ist jetzt bereit für den produktiven Einsatz!${NC}"
    echo -e "${GREEN}   Alle Daten werden automatisch validiert und auf Qualität geprüft.${NC}"
    echo -e "${GREEN}   Keine Halluzinationen - nur echte, verifizierte Gemeindedaten!${NC}"
    echo ""
    
    # Browser öffnen (optional)
    if command -v open &> /dev/null; then
        read -p "🌐 Möchten Sie das Web-Interface jetzt öffnen? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            open "http://localhost:${WEB_PORT}"
        fi
    fi
}

# Hauptfunktion
main() {
    print_header
    
    # Prüfungen
    check_system
    
    # Installation
    install_docker
    install_python_deps
    
    # Setup
    create_docker_files
    setup_directories
    
    # Build & Start
    build_and_start
    
    # Management
    create_management_scripts
    
    # Abschluss
    show_final_info
}

# Fehlerbehandlung
trap 'print_error "Installation fehlgeschlagen! Siehe $LOG_FILE für Details."; exit 1' ERR

# Script ausführen
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi